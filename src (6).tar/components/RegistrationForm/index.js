// Write your JS code here
import {Component} from 'react'

import './index.css'

class RegistrationForm extends Component {
  state = {
    isRegestired: false,
    firstname: '',
    lastname: '',
    validatefirstname: false,
    validatelastname: false,
  }

  onSubmitAnother = () => {
    this.setState({isRegestired: false})
  }

  onSubmit = event => {
    event.preventDefault()
    const {lastname, firstname} = this.state
    const isfirstName = firstname !== ''
    const islastName = lastname !== ''
    if (!isfirstName && !islastName) {
      this.onBlurFirstName()
      this.onBlurLastName()
    } else if (!isfirstName) {
      this.setState({validatelastname: false})
      this.onBlurFirstName()
    } else if (!islastName) {
      this.setState({validatefirstname: false})
      this.onBlurLastName()
    } else {
      this.setState({
        isRegestired: true,
        firstname: '',
        lastname: '',
        validatefirstname: false,
        validatelastname: false,
      })
    }
  }

  onChanngeFristName = event => {
    this.setState({firstname: event.target.value})
  }

  onChangeLastName = event => {
    this.setState({lastname: event.target.value})
  }

  onBlurFirstName = () => {
    const {firstname} = this.state
    const isfilled = firstname === ''
    if (isfilled) {
      this.setState({validatefirstname: isfilled})
      console.log(isfilled)
    }
  }

  onBlurLastName = () => {
    const {lastname} = this.state
    const isfilled = lastname === ''
    if (isfilled) {
      this.setState({validatelastname: isfilled})
    }
  }

  render() {
    const {
      isRegestired,
      firstname,
      lastname,
      validatefirstname,
      validatelastname,
    } = this.state
    const isBlurFirstName = validatefirstname ? 'facusout-input' : ''
    const isBlurFirstNameText = !validatefirstname
      ? 'none-text'
      : 'focusout-text'
    const isBlurLastName = validatelastname ? 'facusout-input' : ''
    const isBlurLastNameText = !validatelastname ? 'none-text' : 'focusout-text'
    return (
      <div className="main-container">
        <div className="main-heading-container">
          <h1 className="main-heading">Registration</h1>
        </div>
        <div className="sub-container">
          {!isRegestired ? (
            <form className="form-container" onSubmit={this.onSubmit}>
              <div className="first-name-container">
                <label className="label" htmlFor="firstName">
                  FIRST NAME
                </label>
                <input
                  type="input"
                  className={`input ${isBlurFirstName}`}
                  onChange={this.onChanngeFristName}
                  id="firstName"
                  onBlur={this.onBlurFirstName}
                  value={firstname}
                  placeholder="First name"
                />
                <p className={`${isBlurFirstNameText}`}>Required</p>
              </div>

              <div className="lastName-container">
                <label className="label" htmlFor="lastName">
                  LAST NAME
                </label>
                <input
                  className={`input ${isBlurLastName}`}
                  placeholder="Last name"
                  type="input"
                  onBlur={this.onBlurLastName}
                  id="lastName"
                  value={lastname}
                  onChange={this.onChangeLastName}
                />
                <p className={`${isBlurLastNameText}`}>Required</p>
              </div>
              <div className="button-container">
                <button type="submit" className="submit-button">
                  Submit
                </button>
              </div>
            </form>
          ) : (
            <div className="success-container">
              <img
                src="https://assets.ccbp.in/frontend/react-js/success-icon-img.png"
                alt="success"
                className="success-img"
              />
              <p className="submitted-text">Submitted Successfully</p>
              <button
                type="button"
                onClick={this.onSubmitAnother}
                className="submit-button-success"
              >
                Submit Another Response
              </button>
            </div>
          )}
        </div>
      </div>
    )
  }
}

export default RegistrationForm
